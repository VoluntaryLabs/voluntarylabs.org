//
//  NavAppAbout.h
//  NavNodeKit
//
//  Created by Steve Dekorte on 10/28/14.
//  Copyright (c) 2014 voluntary.net. All rights reserved.
//

#import "NavInfoNode.h"

@interface NavAppAbout : NavInfoNode

- (NSArray *)aboutNodes;

@end
