# Generated from 'CGContext.h'

def FOUR_CHAR_CODE(x): return x
kCGLineJoinMiter = 0
kCGLineJoinRound = 1
kCGLineJoinBevel = 2
kCGLineCapButt = 0
kCGLineCapRound = 1
kCGLineCapSquare = 2
kCGPathFill = 0
kCGPathEOFill = 1
kCGPathStroke = 2
kCGPathFillStroke = 3
kCGPathEOFillStroke = 4
kCGTextFill = 0
kCGTextStroke = 1
kCGTextFillStroke = 2
kCGTextInvisible = 3
kCGTextFillClip = 4
kCGTextStrokeClip = 5
kCGTextFillStrokeClip = 6
kCGTextClip = 7
kCGEncodingFontSpecific = 0
kCGEncodingMacRoman = 1
kCGInterpolationDefault = 0
kCGInterpolationNone = 1
kCGInterpolationLow = 2
kCGInterpolationHigh = 3
