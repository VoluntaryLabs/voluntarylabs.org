#import <Cocoa/Cocoa.h>

@interface License : NSObject
{
	IBOutlet NSTextField *messageText;
	IBOutlet NSPanel *licencePanel;
	IBOutlet NSTextField *ethernetAddress;
	IBOutlet NSTextField *licenceText;
	IBOutlet NSButton *buyButton;
	NSNumber *price;
}

+ (License *)sharedInstance;
+ (BOOL)ok;

- (void)setMessage:(NSString *)message;

- (BOOL)showLicensePanel;
- (void)setBuyButtonPrice;

- (IBAction)check:sender;

- (IBAction)buy:sender;
- (IBAction)ivePaid:sender;
- (void)registerApp;
- (IBAction)cancel:sender;
- (IBAction)help:sender;

- (void)licenceKey:(NSString *)licence;
- (NSString *)licenceKey;
- (BOOL)hasValidLicense;

@end

#import "CLicense.h"
