#import <Cocoa/Cocoa.h>

@interface CURLHandle : NSObject
{
}

+ (NSString *)stringForUrl:(NSString *)url;
+ propertyListForUrl:(NSString *)url;

+ (NSString *)escape:(NSString *)s;
+ (NSString *)unescape:(NSString *)s;

@end

@interface NSString (CURLHandle)
- (NSString *)urlEncoded;
- (NSString *)urlDecoded;
@end

@interface NSDictionary (CURLHandle)
- (NSString *)formatForHTTP;
@end
