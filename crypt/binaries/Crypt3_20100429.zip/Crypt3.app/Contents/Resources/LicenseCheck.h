#import <Cocoa/Cocoa.h>

@interface LicenseCheck : NSObject 
{
}

- (void)checkInfo;
- (NSDictionary *)info;
- (NSString *)md5OfExecutable;

@end
