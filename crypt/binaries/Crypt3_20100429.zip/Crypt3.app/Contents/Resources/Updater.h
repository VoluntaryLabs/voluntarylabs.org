#import <Cocoa/Cocoa.h>

@interface Updater : NSObject 
{
  NSDictionary *versionDict;
  IBOutlet NSTextField *versionTextField;
}

+ (int)currentVersion;
- (void)setVersionTextField;

- (IBAction)ckeckForUpdates:sender;
- (IBAction)update;
- (int)currentVersion;
- (int)latestVersion;
- (NSString *)latestVersionUrl;
- (NSDictionary *)versionDict;

- (BOOL)needsUpdate;

// ==== Auto update ====

- (void)ckeckForUpdatesIfNeeded;
- (NSDate *)lastUpdateCheck;
- (void)markAsChecked;

@end
