#import <Cocoa/Cocoa.h>

@interface NSString (XmlParse)

- (NSArray *)componentsSeparatedByCharSetAvoidingQuotes:(NSCharacterSet *)charSet;

- (NSArray *)stringsBySplitingFirstOccurenceOf:(NSString *)substring;

- (NSString *)stringByReplacingSubstring:(NSString *)substring
  withString:(NSString *)replaceString;
  
- (NSString *)stringByReplacingCharacterFromSet:(NSCharacterSet *)charSet
  withString:(NSString *)replaceString;
  
- (NSString *)stringByRemovingPaddingCharacterSet:(NSCharacterSet *)charSet;
- (NSString *)stringUnquoted;

@end
