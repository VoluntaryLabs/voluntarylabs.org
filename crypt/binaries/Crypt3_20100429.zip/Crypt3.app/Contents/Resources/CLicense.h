
#import "AppInfo.h"
#import "MachineInfo.h"
#import "MD5Digest.h"

static inline size_t License_sizeAtPath(NSString *path)
{
	NSDictionary *fattrs = [[NSFileManager defaultManager] 
    fileAttributesAtPath:path traverseLink:YES];
	return [[fattrs objectForKey:NSFileSize] intValue];
}

static inline BOOL License_hasValidLicense(void)
{
	NSString *uniqueId = [NSString stringWithFormat:
		@"%@_%@_%i", APP_NAME, macAddressString(), KEY_NUMBER];
	NSString *md5String = [[uniqueId dataUsingEncoding:NSASCIIStringEncoding] 
		md5DigestString];
	NSString *licenceKey = [[NSUserDefaults standardUserDefaults] objectForKey:@"licenceKey"];
	return [licenceKey isEqual:md5String];
}

static inline void License_exitIfNoLicense(void)
{
	if (!License_hasValidLicense()) { exit(1); }
}
