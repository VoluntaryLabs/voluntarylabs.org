#import <Cocoa/Cocoa.h>

NSString *macAddressString(void);

@interface MachineInfo : NSObject
{
}

+ (NSString *)macAddress;

@end