#ifndef __ESCAPE_H
#define __ESCAPE_H

char *url_escape(const char *string, int length);
char *url_unescape(const char *string, int length);

#endif
