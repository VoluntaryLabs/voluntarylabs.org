/* SIZES.H -- DETERMINES THE C TYPES CORRESPONDING TO CERTAIN SIZES
 * MODIFY IT TO FIT YOUR MACHINE
 * TESTED ON A PENTIUM II
 */

#ifndef SIZES_H
#define SIZES_H

typedef unsigned char	byte;		// 1 byte = 8 bits  (unsigned)
typedef unsigned short	word16;		// 2 byte = 16 bits (unsigned)
typedef unsigned int	word32;		// 4 byte = 32 bits (unsigned)
typedef int		s_word32;	// 4 byte = 32 bits (signed)

#endif

