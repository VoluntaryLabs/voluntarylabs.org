#import <Cocoa/Cocoa.h>

@interface NSObject (xmlConverter)
- (NSData *)xmlPropertyListData;
@end
