#import <Cocoa/Cocoa.h>

@interface Marketing : NSObject
{
}

- (IBAction)visitSite:sender;
- (IBAction)feedback:sender;
- (IBAction)tellAFriend:sender;
- (IBAction)donate:sender;

@end
