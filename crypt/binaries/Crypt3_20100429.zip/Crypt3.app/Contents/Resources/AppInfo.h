
#ifndef AppInfo_DEFINED
#define AppInfo_DEFINED

// --- for updater ----
#define CURRENT_VERSION 20100113
#define CHECK_URL @"http://dekorte.com/software/osx/Crypt/version.dict"
#define DAYS_BETWEEN_CHECKS 30

// --- for license ---- 
#define KEY_NUMBER 783462951
#define APP_NAME  @"Crypt"
#define BUY_URL   @"http://dekorte.com/software/osx/Crypt/paypal/buy.cgi?sn=%@&appName=Crypt"
#define FETCH_URL @"http://dekorte.com/software/osx/Crypt/paypal/fetchkey.cgi?appName=Crypt&sn=%@"
#define PRICE_URL @"http://dekorte.com/software/osx/Crypt/price.dict"
#define HELP_URL  @"http://dekorte.com/projects/shareware/faq/"

// --- for marketing ----
#define SITE_URL     @"http://dekorte.com/projects/shareware/Crypt/"
#define FEEDBACK_URL @"mailto:steve@dekorte.com?subject=Crypt"
#define DONATE_URL   @"https://www.paypal.com/xclick/business=steve%40dekorte.com&item_name=Crypt&item_number=All&amount=3.00&currency_code=USD";

#endif